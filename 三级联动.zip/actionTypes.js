/**
 * Created by pangda on 2018/1/23.
 */
export const PEOCINCE_SELECTED = 'province_selected'
export const CITY_SELECTED = 'city_selected'