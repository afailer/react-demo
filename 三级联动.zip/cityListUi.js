import React from 'react'

export default (props) => {
  const {provinceList,cityList,areaList,handleProvinceChange,handleCityChange} = props
  return (
    <div>
      <select onChange={handleProvinceChange}>
        {
          provinceList.map((item,index) => {
            return (
              <option key={item.placeId}
                      value={item.placeId}
                      c-pid={item.placePId}
              >{item.placeName}</option>
            )
          })
        }
      </select>
      <select onChange={handleCityChange}>
        {
          cityList.map((item,index) => {
            return (
              <option key={item.placeId}
                      value={item.placeId}
                      c-pid={item.placePId}
              >{item.placeName}</option>
            )
          })
        }
      </select>
      <select>
        {
          areaList.map((item,index) => {
            return (
              <option key={item.placeId}
                      value={item.placeId}
                      c-pid={item.placePId}
              >{item.placeName}</option>
            )
          })
        }
      </select>
    </div>
  )
}