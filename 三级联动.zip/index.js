import React from 'react';
import ReactDOM from 'react-dom';
import CityList from './CityList';

ReactDOM.render(<CityList />, document.getElementById('root'));
