/**
 * Created by pangda on 2018/1/23.
 */
import {CITY_SELECTED,PEOCINCE_SELECTED} from './actionTypes'

export const getCityListByPro = (index) => ({
  type: PEOCINCE_SELECTED,
  index
})

export const getAreaListByCityId = (index)=> ({
  type: CITY_SELECTED,
  index
})