import React,{Component} from 'react'
import store from './store'
import dispatcher from './dispatcher'
import {getAllProvince , getCityListByPro , getAreaListByCityId} from './actionCreator'
import CityListUi from './cityListUi'

export default class CityList extends Component {
  constructor(props) {
    super(props)
    this.state = store.getState()
    store.on('change',this.handleStoreChange.bind(this))
    this.handleProvinceChange = this.handleProvinceChange.bind(this)
    this.handleCityChange = this.handleCityChange.bind(this)

  }

  render(){
    return (
      <CityListUi
        provinceList = {this.state.provinceList}
        cityList = {this.state.cityList}
        areaList = {this.state.areaList}
        handleProvinceChange={this.handleProvinceChange}
        handleCityChange={this.handleCityChange}
      ></CityListUi>
    )
  }
  handleStoreChange(e){
    this.setState(store.getState())
  }
  handleProvinceChange(e){
     const index = e.target.selectedIndex
     const action = getCityListByPro(index)
     dispatcher.dispatch(action)
  }
  handleCityChange(e){
    const index = e.target.selectedIndex
    console.log(index+"-------")
    const action = getAreaListByCityId(index)
    dispatcher.dispatch(action)
  }
}