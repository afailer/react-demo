import { EventEmitter } from 'events'

const store = Object.assign({},EventEmitter.prototype,{
  state: {
    dataList: [
      {
        placeName:"全国",
        placeId:1,
        placePId:1
      },
      {
        placeName:"山西",
        placeId:2,
        placePId:1
      },
      {
        placeName:"山东",
        placeId:3,
        placePId:1
      },
      {
        placeName:"太原",
        placeId:4,
        placePId:2
      },
      {
        placeName:"大同",
        placeId:8,
        placePId:2
      },
      {
        placeName:"尖草坪",
        placeId:7,
        placePId:4
      },
      {
        placeName:"威海",
        placeId:5,
        placePId:3
      },
      {
        placeName:"烟台",
        placeId:6,
        placePId:3
      },
    ],
    provinceList:[
      {
        placeName:"山西",
        placeId:2,
        placePId:1
      },
      {
        placeName:"山东",
        placeId:3,
        placePId:1
      }
      ],
    cityList:[],
    areaList:[]
  },

  getState() {
    return this.state
  },
  getPlacesByPid(palaceId){
    const pList = [...this.state.dataList]
    const targetCityList = pList.filter(function (item) {
      return item.placePId == palaceId
    })
    return targetCityList
  },
  getCityListByProvinceIndex(index) {
    var placeId = this.state.provinceList.slice(index,index+1)[0].placeId
    const targetCityList = this.getPlacesByPid(placeId)
    console.log(placeId+"----"+targetCityList)
     this.state = {
       dataList: [...this.state.dataList],
       provinceList: [...this.state.provinceList],
       cityList: targetCityList,
       areaList: []
     }
     this.emit('change')
  },
  getAreaListByCityIndex(index){
    var placeId = this.state.cityList.slice(index,index+1)[0].placeId
    const targetAreaList = this.getPlacesByPid(placeId)
    console.log(targetAreaList)
    this.state = {
      dataList: [...this.state.dataList],
      provinceList: [...this.state.provinceList],
      cityList: [...this.state.cityList],
      areaList: targetAreaList
    }
    this.emit('change')
  }
})

export default store