import {Dispatcher} from 'flux'
import store from './store'
import {PEOCINCE_SELECTED,CITY_SELECTED} from './actionTypes'

const dispatcher = new Dispatcher();

dispatcher.register((action) => {
  if(action.type === PEOCINCE_SELECTED) {
    store.getCityListByProvinceIndex(action.index)
  }else if(action.type === CITY_SELECTED){
    store.getAreaListByCityIndex(action.index)
  }
})

export default dispatcher